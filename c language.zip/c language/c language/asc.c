#include<stdio.h>
int main(){
    char c;
    printf("Enter a Charecter : ");
    scanf("%c",&c);
    printf("%c=%d",c,c);
    return 0;
}