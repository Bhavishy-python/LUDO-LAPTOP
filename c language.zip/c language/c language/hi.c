#include<stdio.h>
int main(){
//     int a=10;
//     float b=3.14;
//     char c='A';
//     printf("%d\n",a);
//     printf("%f\n",b);
//     printf("%c\n",c);

int age=15;
float height=5.7;
char name='N';
printf("my age is%d\n",age);
printf("my height is%.1f\n",height);
printf("my name is%c\n",name);

}
