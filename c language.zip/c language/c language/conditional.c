// conditional statement
#include<stdio.h>
int main(){
// int age;
// printf("Enter your age");
// scanf("%d", &age);
// if(age>=18){
//     printf("You are elgible");
// }
// else{
// printf("You are not elgible");
// }

// int num=40;
// printf("enter a number");
// scanf("%d",&num);
// if(num>50){
//     printf("num is GREATER THAN 40",num);
// }
// else if(num<30){
//     printf("num is LESS THAN 40",num);
// }
// else if(num==40){
//     printf("num is equal to 40",num);
// }
// else{
//     printf("ENTER A VALID NUMBER");
// }
// return 0;

// }#include <stdio.h>

    int num = 40;
    printf("Enter a number: ");
    scanf("%d", &num);
    printf("You entered: %d\n", num); // Debug output

    if (num > 50) {
        printf("num is GREATER THAN 50\n");
    } else if (num < 30) {
        printf("num is LESS THAN 30\n");
    } else if (num == 40) {
        printf("num is EQUAL TO 40\n");
    } else {
        printf("Number is between 30 and 50, but not 40\n");
    }

    return 0;
}
