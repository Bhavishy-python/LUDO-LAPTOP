#include<stdio.h>
int main(){
    int a;
    float balance = 10000.00, amount;
    while (1)
    {
        printf("\n===ATM Machine===\n");
        printf("1. Check Balance\n");
        printf("2. Withdraw Mony\n");
        printf("3. Deposit Money\n");
        printf("4. Exit\n");

        printf("Enter Your Choice :\n");
        scanf("%d", &a);

        switch (a)
        {
        case 1:
        printf("Your current balance is : %.2f\n",balance);
            break;

            case 2:
            printf("Enter amount to Withdraw: ");
            scanf("%f",&amount);
            if (amount > balance)
            {
                printf("Insufficient balance!\n");
            } else
            {
                balance -= amount;
                printf("Withdrawl Of the amount Completed! New balance : %.2f\n",balance);
            }
            break;
            
            case 3:
            printf("Enter amount to Deposit the money : ");
            scanf("%f",&amount);
            balance += amount;
            printf("Deposit of your amount is sucessfully credited in your Bank account! New balance: %2.f\n",balance);
            break;

        case 4:
        printf("Thank you for using ATM. Have a great day!!\n");
        default:
        printf("Invalid Choice!please select valid choice\n");
            break;
        }
    }
    
}