#include<stdio.h>
 int main(){
    // int a=10;
    // int b=5;
    // printf("%d",a%b);
    // relstionsl operator
    int a=5;
    int b;
    // printf("%d\n",a==b);
    // printf("%d\n",a!=b);
    // printf("%d\n",a<b);
    // printf("%d\n",a>b);
    // printf("%d\n",a<=b);
    // printf("%d\n",a>=b);
    //logical operator
    // printf("(a<b)&&(a<0):%d\n",a<b&&a<0);
    // printf("(a>b)||(a<b),%d\n",a>b||a<b);
    //Assignment operator
    // a+=5;
    // printf("a+=5 : %d\n",a);
    // increment|decrement operator
    // b=++a;
    // ++a;
    // printf("a=%d\n",a);

    // a++;
    // printf("a=%d\n",a);

    // --a;
    // printf("a=%d\n",a);

    // a--;
    // printf("a=%d\n",a);

    
    

return 0;
 }