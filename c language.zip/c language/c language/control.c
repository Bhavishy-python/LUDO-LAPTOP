#include<stdio.h>
int main(){

// int i;
//     for(int i=5; i>=1;i--){
//         printf(" %d\n",i);

//     }
    // char c;
    // for(c ='z';c>='a';c--){
    //     printf("%c %d\n",c,c);
    // }
    // int n;
    // printf("Enter an Integer :");
    // scanf("%d",&n);
    // for(int i=1;i<=100;++i){
    //     printf("%d*%d=%d\n",n,i,n*i); //for loop
    // }

    // while loo
    // int n =5;
//     
    // while(i<=10){
    //     printf("%d*%d=%d\n",n,i,n*i);
    //     i++;
    // }
    // do
    // {
    //     printf("%c\n",i);
    //     i++;
    // } while (i<='z');
    
    return 0;
}